package com.vti.entity;

public enum Role {
    ADMIN, EMPLOYEE, MANAGER;
}
